# Graphcore

---
## GC Profile

This is a tool for profiling Poplar programs that are run through TensorFlow and PopART.

### Requirements

* The command line tool requires Python 3.
* To view dot files (*currently only available for TensorFlow*) install [graphviz](https://www.graphviz.org/download/) and make sure `dot` is on your path.


### Command line: `gc-profile`

Command line tool and Python package to gather profiling information.

#### Features

* Creates log files for:
  * Poplar
  * PopART
  * TensorFlow
* Provides tile mappings of variables for PopART and TensorFlow
* Extracts total memory from the archive file
* Logs host information
* Logs Poplar and framework versions
* Python package `gcprofile` that helps to retrieve:
  * Poplar graph report
  * Poplar execution report

### Basic usage

Install the gc-profile `.whl` file, then run your program using the CLI. For example:

```
gc-profile [OPTIONS] -- PROGRAM
```

The only required option is `-d` (`--profile-dir`). This specifies the directory to write the profiling information to.

For TensorFlow, you will need to use the `-i` option if you want the execution profile.
This may also be useful for other programs (it is equivalent to the Poplar `debug.instrumentCompute` engine option).

If you want to see the environment variables set by the CLI tool, you can use the verbose, `-v`, option.

Use the `-h` option for more information.

#### Example

```
gc-profile -d profile-dir -- python resnet.py
```

This will create a directory of profiling information in `profile-dir`.

## Retrieving graph and execution reports

To retrieve the graph and execution reports the program must be altered to add functions that uses the environment variables set up by the CLI to find the location for the reports.

#### Poplar

The header file `gcprofile.hpp` provides a utility function `save_poplar_report`. Copy the file to your repository (or copy the source directly; it's only 15 lines) and call the function `save_poplar_report` after your graph program finishes.

For example:

```
#include "gcprofile.hpp"
...
// Create the engine
Engine engine(graph, prog);
engine.load(device);

// Run the control program
std::cout << "Running program\n";
engine.run(0);
std::cout << "Program complete\n";

gcprofile::save_poplar_report(engine);
```

#### Python package `gcprofile`

`gcprofile` is a Python package that provides two utility functions to do this:
`save_tf_report` and `save_popart_report`.

#### TensorFlow

After your graph has been created, add this op on the CPU:
```
from tensorflow.compiler.plugin.poplar.ops import gen_ipu_ops

report = gen_ipu_ops.ipu_event_trace()
```

When configuring the session, specify the profiling arguments:
```
utils.create_ipu_config(profiling=True, profile_execution=True, use_poplar_text_report=False)
```
(Note, setting `profile_execution` will increase memory usage and cycles)

Then, once your program has compiled and run (via `session.run`), retrieve the reports events:

```
raw_reports = session.run(report)
```

Finally, pass the output to the `gcprofile` function to save the profiling information:

```
from gcprofile import save_tf_report
...
save_tf_report(raw_reports)
```

If you are using the `IPUEstimator`, you can use a `SessionRunHook` like this:

```
class ProfilerHook(tf.train.SessionRunHook):
    def begin(self):
        from tensorflow.compiler.plugin.poplar.ops import gen_ipu_ops
        self._report = gen_ipu_ops.ipu_event_trace()

    def end(self, session):
        raw_reports = session.run(self._report)
        from gcprofile import save_tf_report
        save_tf_report(raw_reports)
```

Then you can pass an instance of this hook when training:

```
ipu_estimator.train(input_fn=input_fn, steps=steps, hooks=[ProfilerHook()])
```

#### PopART

A session can be created (using `InferenceSession` or `TrainingSession`), compiled and run. It can then be passed to the `gcprofile` function to save the profiling information.

There are three parts that need to be added to your Python code to implement this.

##### Part 1: Import gcprofile

Add a suitable import statement at the top of the file:
```
import gcprofile
```

##### Part 2: Setup the session options to enable profiling

The profiling options can be added as shown below:
```
options = popart.SessionOptions()
options.engineOptions = {
    "debug.computeInstrumentationLevel": "tile"
}
options.reportOptions = {
    # These options control the summary profiling output
    # and are not required by gc-profile
    "showVarStorage": "true",
    "showPerIpuMemoryUsage": "true",
    "showExecutionSteps": "true"
}
```

##### Part 3: Save the profiling/popart reports

Add the function call to save the profiling data after the session is run:

```
session.run(stepio)

gcprofile.save_popart_report(session)
```

##### Running the program

The file should then be run from command line as follows:

```
gc-profile -d ./profile_dir -v -- python profiling_demo.py
```

The profiling files will be written to the `./profile_dir` directory.

### Examples

Profile the program `resnet.py` and write the profiling information to relative directory `test_profile`:

```
gc-profile -d test_profile -- python resnet.py
```

To see the output from the program being profiled, use the `-p`option:

```
gc-profile -d test_profile -p -- python resnet.py
```

The `-p` option pipes the program's stdout to the shell.

#### Complete PopART example

```
#There are 3 parts that need to be included inside the Python file
# PART 1: Import gcprofile
# PART 2: Setup the session options to enable profiling
# PART 3: Save the profiling/popart reports
# The file should then be run from command line as:
# gc-profile -d ./profile_dir -v -- python profiling_demo.py
# Any profiling files will be written to the ./profile_dir directory

# PART 1: Import gcprofile
import gcprofile

# Define the model as normally
import popart
import scipy as sp
builder = popart.Builder()

a = builder.addInputTensor(popart.TensorInfo("FLOAT16", [1]))
w = builder.addInitializedInputTensor(sp.float16(sp.array([1])))
o = builder.aiOnnx.add([w,a])
builder.addOutputTensor(o)
loss = builder.aiGraphcore.l1loss([o], 1.0)

anchor_config = {
    o: popart.AnchorReturnType("ALL"),
    loss : popart.AnchorReturnType("ALL")
}
dataFlow = popart.DataFlow(1, anchor_config)

# PART 2: Setup the session options to enable profiling
options = popart.SessionOptions()
options.engineOptions = {
    "debug.instrumentCompute":"true", # Equivalent to using the -i option to gc-profile
}
options.reportOptions = {
    "showVarStorage": "true",
    "showPerIpuMemoryUsage": "true",
    "showExecutionSteps": "true"
}

session = popart.TrainingSession(
    fnModel=builder.getModelProto(),
    loss=loss,
    optimizer = popart.ConstSGD(1e-3),
    dataFlow=dataFlow,
    deviceInfo= popart.DeviceManager().createIpuModelDevice({"numIPUs": 1}),
    userOptions=options)

session.prepareDevice()
session.weightsFromHost()

anchors = session.initAnchorArrays()
input_a = sp.float16([1.4])
stepio = popart.PyStepIO({a: input_a}, anchors)
session.run(stepio)

# PART 3 Save the profiling reports
gcprofile.save_popart_report(session)
```
