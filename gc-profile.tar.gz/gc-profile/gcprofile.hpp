#include <fstream>
#include <poplar/Engine.hpp>

namespace gcprofile {

  void save_poplar_report(poplar::Engine &engine) {
    char* log_dir = std::getenv("GC_PROFILE_LOG_DIR");
    std::string dir = log_dir ? std::string(log_dir) : ".";

    // Graph Report
    poplar::ProfileValue graphProfile = engine.getGraphProfile();
    std::ofstream graphReport;
    graphReport.open(dir + "/graph.json");
    poplar::serializeToJSON(graphReport, graphProfile);
    graphReport.close();

    // Execution Report
    poplar::ProfileValue execProfile = engine.getExecutionProfile();
    std::ofstream execReport;
    execReport.open(dir + "/execution.json");
    poplar::serializeToJSON(execReport, execProfile);
    execReport.close();
  }

} // End gcprofile
